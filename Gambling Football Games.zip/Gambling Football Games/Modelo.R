# Modelo de regresión Lineal --------------------------------------------------
#setwd("")

library(tidyverse)
library(tidyquant)
library(haven)
library(openxlsx)
library(dplyr)


list <- c("Qatar",
          "Ecuador",
          "Senegal",
          "Paises Bajos",
          "Inglaterra",
          "Iran",
          "Estados Unidos",
          "Gales",
          "Argentina",
          "Arabia Saudi",
          "Mexico",
          "Polonia",
          "Francia",
          "Australia",
          "Dinamarca",
          "Tunez",
          "España",
          "Costa Rica",
          "Alemania",
          "Japon",
          "Belgica",
          "Canada",
          "Marruecos",
          "Croacia",
          "Brasil",
          "Serbia",
          "Suiza",
          "Camerun",
          "Portugal",
          "Ghana",
          "Uruguay",
          "Corea del Sur")
# data <- read.xlsx()


mean(rpois(100000,3.375))
mean(rpois(100000,2.375))
